import numpy as np
import pdb
from skimage import io

images = np.zeros((9, 400, 600))
# a
num_images = 9
for i in range(num_images):
    images[i, :, :] = np.load('./images/car_%d.npy' % i)

# b    
print('suma tuturor imaginilor ', np.sum(images))
# c
print('suma per image ', np.sum(images, axis=(1,2))) 
# d
print('indexul imaginii cu suma maxima ', np.argmax(np.sum(images, axis=(1, 2))))
# e
mean_image = np.mean(images, axis=0)
io.imshow(mean_image.astype(np.uint8))  
io.show()
# f
std = np.std(images)
print('deviatia standard ', std)
# normalizare
# g
norm_images = (images - mean_image)/std
# h
for i in range(num_images): 
    cropped_image = images[i, 200:300, 280:400]
    io.imshow(cropped_image.astype(np.uint8))  
    io.show()