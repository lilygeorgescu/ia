import numpy as np
import pdb 
from sklearn.utils import shuffle  



# 2
import matplotlib.pyplot as plt

def compute_y(x, W, bias): 
    # dreapta de decizie
    # [x, y] * [W[0], W[1]] + b = 0
    return (-x*W[0] - bias) / (W[1] + 1e-10)

def plot_decision_boundary(X, y , W, b, current_x, current_y): 
    x1 = -0.5 
    y1 = compute_y(x1, W, b) 
    x2 = 0.5 
    y2 = compute_y(x2, W, b)

    # sterge continutul ferestrei
    plt.clf()
    # ploteaza multimea de antrenare
    color = 'r'
    if(current_y == -1):
        color = 'b'
    plt.ylim((-1, 2))
    plt.xlim((-1, 2))        
    plt.plot(X[y == -1, 0], X[y == -1, 1], 'b+')
    plt.plot(X[y == 1, 0], X[y == 1, 1], 'r+')
    # ploteaza exemplul curent
    plt.plot(current_x[0], current_x[1], color+'s')
    # afisarea dreptei de decizie
    plt.plot([x1, x2] ,[y1, y2], 'black')
    plt.show(block=False)
    plt.pause(0.3) 
    
# multimea de antrenare    
X = np.array([
            [0, 0],
            [0, 1],
            [1, 0],
            [1, 1] ] )
X_train = X.copy()
# etichetele 
# or
# y = np.array([-1, 1, 1, 1])
# xor
y = np.array([-1, 1, 1, 1])
W = np.zeros((2)) # initializam ponderile, 2 pt input  
b = 0
# adauga 1 la multimea de antrenare pentru bias 
num_samples = X.shape[0] 

num_epochs = 50
learning_rate = 0.1
for e in range(num_epochs): 
    X, y = shuffle(X, y)
    for i in range(num_samples):
        y_hat = np.dot(X[i][:], W) + b
        loss = ((y_hat - y[i]) ** 2) / 2
        accuracy = (np.sign(np.dot(X, W) + b) == y).mean() 
        print('{}/{} loss =  {} set-accuracy {}'.format(e, i, loss, accuracy))  
        W = W - learning_rate * (y_hat - y[i]) * X[i][:]
        b = b - learning_rate * (y_hat - y[i])
        plot_decision_boundary(X, y, W, b, X[i][:], y[i]) 
 
     
print('acuratetea pe multimea de antrenare este de:', accuracy)
print('ponderile invatate sunt:', W)
print('bias-ul este: ', b) 